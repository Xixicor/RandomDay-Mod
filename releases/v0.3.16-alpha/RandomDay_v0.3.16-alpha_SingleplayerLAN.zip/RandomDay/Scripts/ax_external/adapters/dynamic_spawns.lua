-- RandomDay public source
-- Module: RandomDay/Scripts/ax_external/adapters/dynamic_spawns.lua
-- Ownership/Purpose: RandomDay public module; DynamicSpawns signatures and prepared values
-- Public contract: caller=ax_external/bridge.lua; inputs=active profile adapter ID; outputs=recognized value map
-- Side effects: none directly
-- Failure/Recovery: failures=no complete signature; recovery states=recognized; incompatible
-- Documentation: docs/SOURCE_REFERENCE.md#module-ax-external-adapters-dynamic-spawns

return {
    id = "dynamic_spawns",
    display_name = "Chaotic Spawn Engine / DynamicSpawns",
    required = false,
    compatibility = "Uploaded Chaotic Spawn Engine 0.8.5: runtime settings are read from DynamicSpawns/Scripts/SharedData.lua. The root config.json exists but is not used by the observed startup path.",
    compatibility_signatures = {
        {
            id = "chaotic_spawn_engine_0_8_5_layout",
            tested_version = "",
            version_evidence = "layout_fixture_only",
            observed_layout_label = "0.8.5",
            required_keys = {
                "HardMode", "AreaBasedCooldowns", "stormSpawns", "spawnCycleInterval",
                "globalSpawnsCap", "localSpawnsCap", "portalStormChance", "bossSpawnChance",
            },
        },
    },
    config_candidates = {
        "../DynamicSpawns/Scripts/SharedData.lua",
        "ue4ss/Mods/DynamicSpawns/Scripts/SharedData.lua",
        "./ue4ss/Mods/DynamicSpawns/Scripts/SharedData.lua",
        "Mods/DynamicSpawns/Scripts/SharedData.lua",
        "./Mods/DynamicSpawns/Scripts/SharedData.lua",
    },
    prepared_profiles = {
        standard_pressure = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.5,
            spawnCycleInterval=3, monitorTickInterval=2, minSmallCoolDown=1, maxSmallCoolDown=5, minLargeCoolDown=7, maxLargeCoolDown=17,
            minSpawnDist=1500, maxSpawnDist=15000, globalSpawnsCap=1000, localSpawnsCap=75, modSpawnsCap=500,
            portalStormChance=10, orderBreachChance=10, bossSpawnChance=10, startMessage=true, jokeMessages=true, jokeMsgChance=50, minSpawnsPerArea=7,
        },
        quiet_base_safe = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=false, stormSpawnWarnings=true, hotZones=false, bossSpawns=false, burstSpawns=false, burstSize=0.25,
            spawnCycleInterval=8, monitorTickInterval=4, minSmallCoolDown=8, maxSmallCoolDown=18, minLargeCoolDown=25, maxLargeCoolDown=45,
            minSpawnDist=3000, maxSpawnDist=12000, globalSpawnsCap=400, localSpawnsCap=25, modSpawnsCap=150,
            portalStormChance=0, orderBreachChance=0, bossSpawnChance=0, startMessage=true, jokeMessages=true, jokeMsgChance=35, minSpawnsPerArea=2,
        },
        biohazard_light = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=true, EventActive=true, IsHalloween=true,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=false, burstSpawns=true, burstSize=0.45,
            spawnCycleInterval=4, monitorTickInterval=2, minSmallCoolDown=3, maxSmallCoolDown=8, minLargeCoolDown=12, maxLargeCoolDown=24,
            minSpawnDist=1800, maxSpawnDist=13000, globalSpawnsCap=800, localSpawnsCap=50, modSpawnsCap=320,
            portalStormChance=8, orderBreachChance=4, bossSpawnChance=2, startMessage=true, jokeMessages=true, jokeMsgChance=60, minSpawnsPerArea=5,
        },
        low_pressure_loot_day = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=false, stormSpawnWarnings=true, hotZones=false, bossSpawns=false, burstSpawns=true, burstSize=0.3,
            spawnCycleInterval=6, monitorTickInterval=3, minSmallCoolDown=6, maxSmallCoolDown=14, minLargeCoolDown=18, maxLargeCoolDown=34,
            minSpawnDist=2500, maxSpawnDist=12500, globalSpawnsCap=500, localSpawnsCap=30, modSpawnsCap=200,
            portalStormChance=1, orderBreachChance=1, bossSpawnChance=0, startMessage=true, jokeMessages=true, jokeMsgChance=45, minSpawnsPerArea=3,
        },
        security_pressure = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.7,
            spawnCycleInterval=2, monitorTickInterval=2, minSmallCoolDown=1, maxSmallCoolDown=3, minLargeCoolDown=5, maxLargeCoolDown=12,
            minSpawnDist=1200, maxSpawnDist=16000, globalSpawnsCap=1200, localSpawnsCap=95, modSpawnsCap=700,
            portalStormChance=12, orderBreachChance=16, bossSpawnChance=12, startMessage=true, jokeMessages=true, jokeMsgChance=55, minSpawnsPerArea=9,
        },
        weather_wandering = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=true, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.55,
            spawnCycleInterval=3, monitorTickInterval=2, minSmallCoolDown=2, maxSmallCoolDown=6, minLargeCoolDown=8, maxLargeCoolDown=18,
            minSpawnDist=1800, maxSpawnDist=17000, globalSpawnsCap=1000, localSpawnsCap=70, modSpawnsCap=500,
            portalStormChance=20, orderBreachChance=8, bossSpawnChance=8, startMessage=true, jokeMessages=true, jokeMsgChance=65, minSpawnsPerArea=7,
        },
        night_pressure = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=true, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=true, EventActive=true, IsHalloween=true,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.85,
            spawnCycleInterval=2, monitorTickInterval=2, minSmallCoolDown=1, maxSmallCoolDown=4, minLargeCoolDown=5, maxLargeCoolDown=13,
            minSpawnDist=1200, maxSpawnDist=18000, globalSpawnsCap=1300, localSpawnsCap=110, modSpawnsCap=750,
            portalStormChance=18, orderBreachChance=14, bossSpawnChance=14, startMessage=true, jokeMessages=true, jokeMsgChance=70, minSpawnsPerArea=10,
        },
        speedrun_pressure = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=false, CalendarEvents=false, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=false, burstSpawns=true, burstSize=0.65,
            spawnCycleInterval=2, monitorTickInterval=1, minSmallCoolDown=1, maxSmallCoolDown=4, minLargeCoolDown=6, maxLargeCoolDown=14,
            minSpawnDist=2500, maxSpawnDist=22000, globalSpawnsCap=900, localSpawnsCap=55, modSpawnsCap=450,
            portalStormChance=8, orderBreachChance=6, bossSpawnChance=2, startMessage=true, jokeMessages=true, jokeMsgChance=40, minSpawnsPerArea=6,
        },
        scarcity_low_frequency = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=false, bossSpawns=false, burstSpawns=false, burstSize=0.25,
            spawnCycleInterval=7, monitorTickInterval=3, minSmallCoolDown=8, maxSmallCoolDown=20, minLargeCoolDown=28, maxLargeCoolDown=55,
            minSpawnDist=2600, maxSpawnDist=14000, globalSpawnsCap=450, localSpawnsCap=28, modSpawnsCap=180,
            portalStormChance=3, orderBreachChance=3, bossSpawnChance=1, startMessage=true, jokeMessages=true, jokeMsgChance=25, minSpawnsPerArea=2,
        },
        minimum_pressure = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=false, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=false, stormSpawnWarnings=true, hotZones=false, bossSpawns=false, burstSpawns=false, burstSize=0.15,
            spawnCycleInterval=10, monitorTickInterval=5, minSmallCoolDown=12, maxSmallCoolDown=28, minLargeCoolDown=40, maxLargeCoolDown=70,
            minSpawnDist=3500, maxSpawnDist=12000, globalSpawnsCap=300, localSpawnsCap=18, modSpawnsCap=100,
            portalStormChance=0, orderBreachChance=0, bossSpawnChance=0, startMessage=true, jokeMessages=true, jokeMsgChance=35, minSpawnsPerArea=1,
        },
        training_targets = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=false, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=false, burstSpawns=true, burstSize=0.35,
            spawnCycleInterval=5, monitorTickInterval=2, minSmallCoolDown=4, maxSmallCoolDown=10, minLargeCoolDown=16, maxLargeCoolDown=30,
            minSpawnDist=2200, maxSpawnDist=14000, globalSpawnsCap=550, localSpawnsCap=35, modSpawnsCap=250,
            portalStormChance=3, orderBreachChance=2, bossSpawnChance=0, startMessage=true, jokeMessages=true, jokeMsgChance=55, minSpawnsPerArea=4,
        },
        hard_pressure = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=true, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=false, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=1.0,
            spawnCycleInterval=1, monitorTickInterval=1, minSmallCoolDown=1, maxSmallCoolDown=2, minLargeCoolDown=4, maxLargeCoolDown=9,
            minSpawnDist=1000, maxSpawnDist=20000, globalSpawnsCap=1500, localSpawnsCap=125, modSpawnsCap=900,
            portalStormChance=25, orderBreachChance=20, bossSpawnChance=18, startMessage=true, jokeMessages=true, jokeMsgChance=65, minSpawnsPerArea=12,
        },
        slow_attrition = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=false, bossSpawns=true, burstSpawns=false, burstSize=0.3,
            spawnCycleInterval=6, monitorTickInterval=3, minSmallCoolDown=7, maxSmallCoolDown=16, minLargeCoolDown=22, maxLargeCoolDown=45,
            minSpawnDist=2000, maxSpawnDist=15000, globalSpawnsCap=650, localSpawnsCap=42, modSpawnsCap=280,
            portalStormChance=6, orderBreachChance=6, bossSpawnChance=8, startMessage=true, jokeMessages=true, jokeMsgChance=30, minSpawnsPerArea=4,
        },
        relief_day = {
            HardMode=false, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=true, AreaBasedCooldowns=true, CalendarEvents=false, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=false, stormSpawnWarnings=true, hotZones=false, bossSpawns=false, burstSpawns=false, burstSize=0.15,
            spawnCycleInterval=12, monitorTickInterval=5, minSmallCoolDown=16, maxSmallCoolDown=34, minLargeCoolDown=50, maxLargeCoolDown=90,
            minSpawnDist=4000, maxSpawnDist=11000, globalSpawnsCap=250, localSpawnsCap=15, modSpawnsCap=80,
            portalStormChance=0, orderBreachChance=0, bossSpawnChance=0, startMessage=true, jokeMessages=true, jokeMsgChance=80, minSpawnsPerArea=1,
        },
        precision_patrols = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=false, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=true, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.5,
            spawnCycleInterval=3, monitorTickInterval=2, minSmallCoolDown=2, maxSmallCoolDown=5, minLargeCoolDown=9, maxLargeCoolDown=18,
            minSpawnDist=2500, maxSpawnDist=18000, globalSpawnsCap=900, localSpawnsCap=60, modSpawnsCap=420,
            portalStormChance=8, orderBreachChance=14, bossSpawnChance=10, startMessage=true, jokeMessages=true, jokeMsgChance=35, minSpawnsPerArea=6,
        },
        experimental_mixed = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=true, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=false, CalendarEvents=true, EventDebugMode=true, EventActive=true, IsHalloween=true,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=0.9,
            spawnCycleInterval=2, monitorTickInterval=1, minSmallCoolDown=1, maxSmallCoolDown=6, minLargeCoolDown=5, maxLargeCoolDown=15,
            minSpawnDist=1200, maxSpawnDist=25000, globalSpawnsCap=1400, localSpawnsCap=115, modSpawnsCap=850,
            portalStormChance=22, orderBreachChance=18, bossSpawnChance=16, startMessage=true, jokeMessages=true, jokeMsgChance=90, minSpawnsPerArea=11,
        },
        capstone_pressure = {
            HardMode=true, EVERYTHINGSLOOSE=false, PortalStormsEverywhere=true, cullDistantNPCs=false,
            PlayerCountBasedCooldowns=false, AreaBasedCooldowns=false, CalendarEvents=true, EventDebugMode=false, EventActive=false, IsHalloween=false,
            stormSpawns=true, stormSpawnWarnings=true, hotZones=true, bossSpawns=true, burstSpawns=true, burstSize=1.0,
            spawnCycleInterval=1, monitorTickInterval=1, minSmallCoolDown=1, maxSmallCoolDown=2, minLargeCoolDown=3, maxLargeCoolDown=8,
            minSpawnDist=900, maxSpawnDist=26000, globalSpawnsCap=1700, localSpawnsCap=140, modSpawnsCap=1000,
            portalStormChance=30, orderBreachChance=25, bossSpawnChance=20, startMessage=true, jokeMessages=true, jokeMsgChance=75, minSpawnsPerArea=14,
        }
    }
}
