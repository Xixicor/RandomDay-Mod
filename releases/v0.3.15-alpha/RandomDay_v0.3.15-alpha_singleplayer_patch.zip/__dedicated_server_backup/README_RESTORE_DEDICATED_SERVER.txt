Dedicated-server restore files for RandomDay v0.3.15-alpha

This folder contains the original dedicated-server versions of every file edited by the singleplayer patch.

Backed-up files:
- RandomDay/.randomday_version
- RandomDay/Scripts/ax_config/server.lua
- RandomDay/Scripts/ax_core/init.lua
- RandomDay/Scripts/ax_sandbox/writer.lua

Restore method:
1. Stop the server/game.
2. Copy the files from __dedicated_server_backup/RandomDay/ over the matching files in RandomDay/.
3. Restart.

Alternative restore method:
Reinstall the original RandomDay v0.3.15-alpha package.

Important:
The singleplayer patch intentionally disables dedicated-server sandbox path writes and third-party external mod patching. Restore these backup files before using this install as the normal dedicated-server build.
