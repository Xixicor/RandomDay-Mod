local M = {}

local function normalize_path(path)
    path = tostring(path or ""):gsub("\\", "/")
    path = path:gsub("/+", "/")
    path = path:gsub("/$", "")
    return path
end

local function manual_singleplayer_target()
    local root = normalize_path(_G.RANDOMDAY_MOD_ROOT or _G["RandomDay_" .. "RANDOMDAY_MOD_ROOT"] or "RandomDay")
    return root .. "/runtime/singleplayer_manual/SandboxSettings.ini"
end

local function is_inside(path, root)
    path = normalize_path(path)
    root = normalize_path(root)
    return path == root or path:sub(1, #root + 1) == (root .. "/")
end

local function validate_target_allowed(path)
    local root = normalize_path(_G.RANDOMDAY_MOD_ROOT or _G["RandomDay_" .. "RANDOMDAY_MOD_ROOT"] or "RandomDay")
    local allowed_root = root .. "/runtime/singleplayer_manual"
    if not is_inside(path, allowed_root) then
        return false, "singleplayer patch refused external sandbox target: " .. tostring(path)
    end
    return true
end

function M.resolve_sandbox_path(config, utils)
    -- Locked safety behavior for this public patch: ignore sandbox_path_override and candidates.
    -- The dedicated-server version can be restored from __dedicated_server_backup_v0.3.15.
    return manual_singleplayer_target()
end

function M.resolve_all_sandbox_targets(config, utils)
    return { M.resolve_sandbox_path(config, utils) }
end

local function write_optional_mirror(config, utils, backup, path, profile, rendered, rendered_hash, mod_root, log)
    if not path or path == "" then return false end
    local allowed, why = validate_target_allowed(path)
    if not allowed then
        log.warn(why)
        return false
    end

    local existing = utils.read_file(path)
    if existing and utils.hash_text(existing) == rendered_hash then
        log.info("sandbox mirror already matches Day " .. tostring(profile.day) .. " at " .. tostring(path))
        return true
    end

    utils.mkdir(utils.dirname(path))
    if existing and config.sandbox.backup_before_write then
        local backup_dir = config.paths.runtime_dir .. "/backups/mirror_" .. utils.timestamp() .. "_day" .. tostring(profile.day)
        utils.mkdir(backup_dir)
        utils.copy_file(path, backup_dir .. "/" .. utils.basename(path))
    end

    local ok, err = utils.write_file(path, rendered)
    if not ok then
        log.warn("optional sandbox mirror write skipped/failed path=" .. tostring(path) .. " err=" .. tostring(err))
        return false
    end
    local readback = utils.read_file(path)
    if not readback or utils.hash_text(readback) ~= rendered_hash then
        log.warn("optional sandbox mirror readback mismatch path=" .. tostring(path))
        return false
    end
    log.info("sandbox mirror wrote Day " .. tostring(profile.day) .. "/17 - " .. profile.display_name .. " to " .. tostring(path))
    return true
end

function M.ensure_profile_written(config, profiles, profile, mod_root, log, reason)
    local utils = dofile(mod_root .. "/Scripts/ax_core/utils.lua")
    local schema = dofile(mod_root .. "/Scripts/ax_sandbox/schema.lua")
    local serializer = dofile(mod_root .. "/Scripts/ax_sandbox/serializer.lua")
    local validator = dofile(mod_root .. "/Scripts/ax_sandbox/validator.lua")
    local backup = dofile(mod_root .. "/Scripts/ax_backup/manager.lua")

    local ok, err = validator.validate_profile(profile, schema)
    if not ok then return { ok=false, error="profile validation failed: " .. tostring(err) } end

    local sandbox_path = M.resolve_sandbox_path(config, utils)
    local allowed, why = validate_target_allowed(sandbox_path)
    if not allowed then return { ok=false, error=why, sandbox_path=sandbox_path } end

    utils.mkdir(utils.dirname(sandbox_path))
    local rendered = serializer.render_ini(profile, schema, utils)
    local rendered_hash = utils.hash_text(rendered)

    local existing = utils.read_file(sandbox_path)
    local primary_already_current = existing and utils.hash_text(existing) == rendered_hash
    if primary_already_current and not config.sandbox.force_rewrite_every_supervision_tick then
        log.info("sandbox already matches Day " .. tostring(profile.day) .. " at " .. sandbox_path)
        backup.update_last_good(config, sandbox_path, profile, rendered_hash, mod_root, log)
        return { ok=true, changed=false, sandbox_path=sandbox_path, hash=rendered_hash, already_current=true, mirrors_written=0, manual_singleplayer_output=true }
    end

    local pending_path = config.paths.runtime_dir .. "/pending/SandboxSettings.ini.pending"
    utils.mkdir(utils.dirname(pending_path))
    local w_ok, w_err = utils.write_file(pending_path, rendered)
    if not w_ok then return { ok=false, error="pending write failed: " .. tostring(w_err), sandbox_path=sandbox_path } end

    local pending_text, rerr = utils.read_file(pending_path)
    if not pending_text then return { ok=false, error="pending readback failed: " .. tostring(rerr), sandbox_path=sandbox_path } end
    local v_ok, v_err = validator.validate_ini_text(pending_text, profile, schema)
    if not v_ok then return { ok=false, error="pending validation failed: " .. tostring(v_err), sandbox_path=sandbox_path } end

    local backup_dir = backup.backup_current(config, sandbox_path, profile, mod_root, log)

    os.remove(sandbox_path)
    local rename_ok, rename_err = os.rename(pending_path, sandbox_path)
    if not rename_ok then
        log.error("manual-output rename failed: " .. tostring(rename_err))
        if config.sandbox.restore_last_good_on_failure then
            backup.restore_last_good(config, sandbox_path, mod_root, log)
        end
        return { ok=false, error="manual-output rename failed: " .. tostring(rename_err), sandbox_path=sandbox_path, backup_dir=backup_dir }
    end

    local production_text, perr = utils.read_file(sandbox_path)
    if not production_text then return { ok=false, error="manual-output readback failed: " .. tostring(perr), sandbox_path=sandbox_path, backup_dir=backup_dir } end
    local prod_ok, prod_err = validator.validate_ini_text(production_text, profile, schema)
    if not prod_ok then
        log.error("manual-output validation failed: " .. tostring(prod_err))
        if config.sandbox.restore_last_good_on_failure then backup.restore_last_good(config, sandbox_path, mod_root, log) end
        return { ok=false, error="manual-output validation failed: " .. tostring(prod_err), sandbox_path=sandbox_path, backup_dir=backup_dir }
    end

    backup.update_last_good(config, sandbox_path, profile, rendered_hash, mod_root, log)
    log.info("wrote singleplayer manual-output SandboxSettings Day " .. tostring(profile.day) .. "/17 - " .. profile.display_name .. " to " .. sandbox_path)
    log.warn("manual step required: copy the generated SandboxSettings.ini to the intended singleplayer world, then restart/load the world")

    return { ok=true, changed=true, sandbox_path=sandbox_path, hash=rendered_hash, backup_dir=backup_dir, mirrors_written=0, manual_singleplayer_output=true }
end

return M
