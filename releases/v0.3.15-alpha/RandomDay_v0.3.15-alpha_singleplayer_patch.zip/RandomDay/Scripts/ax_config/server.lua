return {
    version = "0.3.15-alpha-singleplayer-patch",
    plan_basis = "RandomDay v0.3.15 singleplayer manual-output patch",

    logging = {
        level = "info"
    },

    cycle = {
        application_mode = "next_reboot_queue",
        cycle_length_days = 17,
        bootstrap_day = 1,
        check_interval_ms = 0
    },

    profile_family = {
        -- selected_run = always use selected_family.
        -- non_repeating_random_run = choose one unused family at Day 1, keep it through Day 17, then choose another unused family.
        -- rotation_run = deterministic listed order, still locked through Day 17.
        mode = "non_repeating_random_run", -- selected_run | non_repeating_random_run | rotation_run
        selected_family = "action",
        default_family = "action",
        allowed_families = {
            "action", "survival", "stealth", "horde", "boss_hunt", "scavenger", "builder", "expedition",
            "security_lockdown", "biohazard", "anteverse", "nightmare", "weathered", "precision",
            "logistics", "experimental", "compliance_test",
        },
        preserve_family_until_day_17 = true,
        reroll_only_after_day_17 = true,
        prevent_repeats_until_rotation_complete = true
    },

    world_scope = {
        enabled = true,
        affect_open_worlds = true,
        unknown_world_policy = "allow", -- allow | block
        log_scope_decisions = true,
        protected_worlds = {},
    },

    paths = {
        runtime_dir = "ue4ss/Mods/RandomDay/runtime",
        web_export_dir = "ue4ss/Mods/RandomDay/web_export",

        -- PUBLIC SINGLEPLAYER SAFETY MODEL:
        -- This patch intentionally does not search AppData, USERPROFILE, Documents, Steam userdata, or save folders.
        -- It does not write to a real singleplayer world automatically.
        -- It generates SandboxSettings.ini inside the RandomDay mod folder only.
        -- Players manually copy the generated file into the singleplayer world they choose.
        singleplayer_manual_only = true,
        singleplayer_manual_subdir = "runtime/singleplayer_manual",
        sandbox_path_override = nil,

        sandbox_candidates = {
            "runtime/singleplayer_manual/SandboxSettings.ini",
        },

        write_sandbox_mirrors = false,
        sandbox_mirror_required = false,
        world_name = nil,
        sandbox_mirror_candidates = {
        }
    },

    sandbox = {
        backup_before_write = true,
        restore_last_good_on_failure = true,
        force_rewrite_every_supervision_tick = false
    },

    -- Disabled in this public singleplayer/manual patch. This prevents writes to third-party mod folders.
    -- Dedicated-server users should restore the backup files or use the normal v0.3.15 package.
    external_mods = {
        enabled = false,
        optional_by_default = true,
        patch_only_existing_keys = true,
        backup_before_write = true,
        adapters = {
        }
    },

    player_message = {
        enabled = true,
        log_on_startup = true,
        register_console_command = false,
        console_command = "randomday",
        broadcast_enabled = true,
        startup_delay_ms = 30000,
        join_check_interval_ms = 15000,
        send_daily_joke_after_join = true,
        daily_joke_delay_seconds = 10,
        criticality_join = 2,
        criticality_joke = 0
    }
}
