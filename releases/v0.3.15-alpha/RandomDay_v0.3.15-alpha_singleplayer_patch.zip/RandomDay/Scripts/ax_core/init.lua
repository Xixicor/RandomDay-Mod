local M = {}

function M.run(mod_root)
    local log = dofile(mod_root .. "/Scripts/ax_core/log.lua")
    local utils = dofile(mod_root .. "/Scripts/ax_core/utils.lua")
    local config = dofile(mod_root .. "/Scripts/ax_config/server.lua")
    local profiles = dofile(mod_root .. "/Scripts/ax_profiles/randomday_17.lua")
    local calendar = dofile(mod_root .. "/Scripts/ax_cycle/calendar.lua")
    local writer = dofile(mod_root .. "/Scripts/ax_sandbox/writer.lua")
    local external = dofile(mod_root .. "/Scripts/ax_external/bridge.lua")
    local web = dofile(mod_root .. "/Scripts/ax_web/export.lua")
    local player = dofile(mod_root .. "/Scripts/ax_player/message.lua")

    log.configure(config.logging or {})

    -- Singleplayer patch safety boundary:
    -- Runtime/export paths and generated SandboxSettings output are anchored to this mod folder.
    -- This patch intentionally does not add or discover any server, AppData, user-profile, document, or save-folder path.
    config.paths.runtime_dir = mod_root .. "/runtime"
    config.paths.web_export_dir = mod_root .. "/web_export"
    config.paths.sandbox_path_override = nil
    config.paths.singleplayer_manual_only = true
    config.paths.write_sandbox_mirrors = false
    config.paths.sandbox_candidates = {
        mod_root .. "/runtime/singleplayer_manual/SandboxSettings.ini",
    }
    config.paths.sandbox_mirror_candidates = {}

    log.info("starting version " .. tostring(config.version) .. " mode=next_reboot_queue mod_root=" .. tostring(mod_root))
    log.warn("singleplayer manual-output patch active: RandomDay writes only inside RandomDay/runtime/singleplayer_manual; copy SandboxSettings.ini manually to the intended world")
    utils.ensure_runtime_dirs(config, mod_root, log)

    local function prepare_next_reboot(reason)
        local sandbox_path = writer.resolve_sandbox_path(config, utils)
        local existing = utils.read_file(sandbox_path) or ""
        local selected = calendar.select_next_reboot_profile(config, profiles, existing)

        if selected.active_profile then
            log.info("active loaded profile marker: Day " .. tostring(selected.active_profile.day) .. "/" .. tostring(profiles.cycle_length_days) .. " - " .. tostring(selected.active_profile.display_name))
        else
            log.warn("no RandomDay active profile marker found in SandboxSettings.ini; preparing bootstrap Day " .. tostring(selected.prepared_day) .. " for next reboot")
        end

        local profile = selected.prepared_profile
        if not profile then
            log.error("no profile selected for next reboot; reason=" .. tostring(reason))
            return false
        end

        log.info("preparing NEXT REBOOT profile " .. tostring(profile.family_label or profile.family or "") .. " Day " .. tostring(profile.day) .. "/" .. tostring(profiles.cycle_length_days) .. " - " .. profile.display_name .. " reason=" .. tostring(reason))

        local write_result = writer.ensure_profile_written(config, profiles, profile, mod_root, log, reason)
        if write_result.ok then
            local external_profile = selected.active_profile or profile
            log.info("external adapters target active-loaded profile Day " .. tostring(external_profile.day) .. "/" .. tostring(profiles.cycle_length_days) .. " - " .. tostring(external_profile.display_name))
            local external_result = external.apply_profile(config, external_profile, mod_root, log)
            if calendar.commit_selection then calendar.commit_selection(config, profiles, selected, mod_root, log) end
            web.export_next_reboot(config, profiles, selected, mod_root, log, write_result, external_result)
            player.install_next_reboot(config, profiles, selected, mod_root, log)
            return true
        else
            log.error("next reboot profile write failed: " .. tostring(write_result.error))
            web.export_failure(config, profiles, profile, selected, mod_root, log, write_result)
            return false
        end
    end

    prepare_next_reboot("startup")

    local interval = tonumber(config.cycle and config.cycle.check_interval_ms) or 0
    if interval > 0 and LoopAsync then
        LoopAsync(interval, function()
            local ok, err = pcall(function()
                prepare_next_reboot("supervision_loop")
            end)
            if not ok then log.error("supervision error: " .. tostring(err)) end
            return false
        end)
        log.info("registered next-reboot supervision loop interval_ms=" .. tostring(interval))
    else
        log.info("supervision loop disabled; next-reboot profile prepared once at startup")
    end
end

return M
