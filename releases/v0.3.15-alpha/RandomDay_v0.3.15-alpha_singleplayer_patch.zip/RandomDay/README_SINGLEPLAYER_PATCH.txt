RandomDay v0.3.15-alpha Singleplayer Patch
Safe manual-output overwrite patch

Base required:
- RandomDay v0.3.15-alpha

Purpose:
This patch adds a safe singleplayer/manual-output mode for RandomDay v0.3.15-alpha.

What this patch does:
- Generates the next RandomDay SandboxSettings.ini inside the RandomDay mod folder only.
- Uses the existing RandomDay next-reboot / next-launch model.
- Disables dedicated-server sandbox mirror writes.
- Disables third-party external mod patching in this singleplayer/manual package.
- Keeps the 17-day family rotation behavior from v0.3.15-alpha.

Safe output path:
RandomDay/runtime/singleplayer_manual/SandboxSettings.ini

What this patch does NOT do:
- It does not scan AppData.
- It does not scan USERPROFILE.
- It does not scan Documents.
- It does not scan Steam userdata.
- It does not search local save folders.
- It does not write directly into real singleplayer world folders.
- It does not write to dedicated-server sandbox paths.
- It does not patch third-party mod folders.

Install:
1. Install RandomDay v0.3.15-alpha normally.
2. Extract this patch over the existing ue4ss/Mods folder.
3. Allow overwrite for the included RandomDay files.
4. Launch the game with UE4SS and RandomDay enabled.
5. Let RandomDay generate:
   RandomDay/runtime/singleplayer_manual/SandboxSettings.ini
6. Back up the target singleplayer world's original SandboxSettings.ini.
7. Manually copy the generated SandboxSettings.ini into the intended world folder.
8. Fully restart/reload the world so Abiotic Factor reads the copied settings.

Dedicated-server note:
This patch is not the normal dedicated-server package. The original dedicated-server versions of the edited files are included under:
__dedicated_server_backup/

To restore dedicated-server behavior, copy the backed-up files from that folder over the patched RandomDay files, or reinstall the original RandomDay v0.3.15-alpha package.
